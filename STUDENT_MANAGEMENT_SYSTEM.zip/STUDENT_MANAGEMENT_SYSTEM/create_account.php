<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create an account</title>
</head>
<body>
    <center>
<form action="" method="POST">
<h2>Creating an Account</h2>
<?php
include('connection.php');
if(isset($_POST['submit']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    $email=$_POST['email'];

    if(empty($username) && empty($password) && empty($email))
    {
        echo "All fields Arerquired";
    }
    else
    {
        $insert="INSERT INTO users(username,password,email) VALUES('$username','$password','$email')";
        $query=mysqli_query($connection,$insert);
        if($query == true)
        {
            $_SESSION['username']=$username;
            header("location:login.php");
        }
        else
        {
            echo"Failed to Create an Account";
        }
    }
}
?>
            <p>User Name: <input type="text" name="username" placeholder="Enter Username"></p>
            <p>Password: <input type="password" name= "password" placeholder="Enter your password"></p>
            <p>Email: <input type="email" name="email" placeholder="Email eg: example@gmail.com"></p>
            <p><input type="submit" name="submit" value="Create"></p>

</form>
        
    </center>
</body>
</html>