<?php
$connection = mysqli_connect("localhost","root","","student_management");
if(!$connection)
{
die("Connection Successfull".mysqli_error());
}
?>