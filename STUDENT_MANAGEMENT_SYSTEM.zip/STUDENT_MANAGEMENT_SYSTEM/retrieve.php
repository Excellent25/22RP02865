<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Viewing page</title>
</head>
<body>
    
        <center>
        <a href="home.php" style="text-decoration:none;font-size:50px; background-color:aquamarine;">HOME</a>
            <h1>Viewing Added Students</h1>
        <table border="1">
            <tr>
            <th>Student ID</th>
                <th>FirstName</th>
                <th>LastName</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Class</th>
                <th>Contacts</th>
                <th>Email</th>
                <th>Address</th>
                <th colspan="2">Action</th>
            </tr>
            <?php
include('connection.php');

// Query to select all records from the student table
$select = "SELECT * FROM student";
$query = mysqli_query($connection, $select);

// Check if the query returns any rows
if (mysqli_num_rows($query) > 0) {
    // Loop through the query result to fetch each row as an associative array
    while ($row = mysqli_fetch_assoc($query)) {
        $id = $row['id']; // Assigning values from the row to variables
        $fname = $row['first_name'];
        $lname = $row['last_name'];
        $date = $row['date_of_birth'];
        $gender = $row['gender'];
        $class = $row['class'];
        $contact = $row['contact_number'];
        $email = $row['email'];
        $address = $row['address'];
        ?>
        <tr>
            <td><?php echo $id; ?></td>
            <td><?php echo $fname; ?></td>
            <td><?php echo $lname; ?></td>
            <td><?php echo $date; ?></td>
            <td><?php echo $gender; ?></td>
            <td><?php echo $class; ?></td>
            <td><?php echo $contact; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php echo $address; ?></td>
            <td>
                <a href="update.php?id=<?php echo $row['id']; ?>">Update</a>&nbsp;&nbsp;
                <a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php 
    }
}
?>
        </table>
        </center>
 
  
</body>
</html>